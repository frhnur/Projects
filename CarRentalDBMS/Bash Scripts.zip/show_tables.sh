#!/bin/bash
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib

read -p "Enter username: " user
read -sp "Enter password: " pwd
echo

sqlplus64 "${user}/${pwd}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- Show Tables
-- ======================================================
SELECT * FROM Customer;
SELECT * FROM Vehicle;
SELECT * FROM VehicleColour;
SELECT * FROM Review;
SELECT * FROM Reservation;
SELECT * FROM Maintenance;
SELECT * FROM Repairs;
SELECT * FROM PartsRepaired;
SELECT * FROM Cleaning;
SELECT * FROM Rental;
SELECT * FROM Payment;

-- Show Views
-- ======================================================
SELECT * FROM customer_reservations;
SELECT * FROM customers_with_phone;
SELECT * FROM customer_info;
SELECT * FROM luxury_vehicles;
SELECT * FROM vehiclerepairs_andparts;
SELECT * FROM pending_reservations;

exit;
EOF

