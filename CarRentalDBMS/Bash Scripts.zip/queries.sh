#!/bin/bash
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib

read -p "Enter username: " user
read -sp "Enter password: " pwd
echo

sqlplus64 "${user}/${pwd}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- ======================================================================
-- Simple Queries
-- 1. Customer
-- ======================================================

-- Q1: List all cities where customers live and count how many customers are in each city
-- Group results by city and ordered alphabetically.
SELECT City, COUNT(*) AS "Number of Customers"
FROM Customer
GROUP BY City
ORDER BY City;

-- Q2: Retrieve all customers who do not have a phone number listed
SELECT *
FROM Customer
WHERE PhoneNumber IS NULL
ORDER BY FirstName, LastName;


-- 2. Vehicle
-- ======================================================

-- Q1: List all unique daily rates for vehicles in descending order
SELECT DISTINCT DailyRate
FROM Vehicle
ORDER BY DailyRate DESC;

--  Q2: Count the number of vehicles available in each vehicle type (Economy, Luxury)
SELECT VType, COUNT(*) AS "Number of Vehicles Available"
FROM Vehicle
WHERE VStatus = 'Available'
GROUP BY VType;


-- 3. VehicleColour
-- ======================================================

-- Q1: Show how many colours are associated with each vehicle
SELECT DISTINCT VehicleID AS , COUNT(*) AS "Number of Colours"
FROM VehicleColour
GROUP BY VehicleID
ORDER BY "Number of Colours" DESC;


-- 4. Review
-- ======================================================

-- Q1: Retrieve all reviews with ratings less than 5, ordering results from lowest to highest rating
SELECT *
FROM Review
WHERE rating < 5
ORDER BY rating;


-- 5. Reservation
-- ======================================================

-- Q1: Show the number of reservations for each reservation status (Pending, Confirmed, Cancelled)
-- Group by status, and labelled the result as "Reservation_Count". Ordered the output so that statuses with the highest counts appear first.
SELECT RStatus, COUNT(DISTINCT ReservationID) AS Reservation_Count
FROM Reservation
GROUP BY RStatus
ORDER BY Reservation_Count DESC;

-- Q2: Retrieve a distinct list of vehicles with their pickup dates, ensuring each vehicle pickup date pair appears only once
-- Order the results by pickup date in ascending order so that earlier reservations appear first
SELECT DISTINCT VehicleID, PPickupDate
FROM Reservation
ORDER BY PPickupDate ASC;


-- 6. Maintenance
-- ======================================================

-- Q1: List all the vehicles that have completed maintenance and that is sorted from most most recent to least recent  ISSUE
SELECT *
FROM maintenance
WHERE MStatus = 'Maintenance_Completed'
ORDER BY ServiceDate DESC;

-- Q2: Count the number of vehicles that are currently under maintenance.
SELECT VehicleID, COUNT(*) AS UndergoingMaintenance
FROM maintenance
WHERE MStatus = 'Under_Maintenance'
GROUP BY VehicleID; -- each vehicle id becomes single group


-- 7. Repairs
-- ======================================================

-- Q1: List repair types in least to most often in need of a repair
SELECT RepairType, COUNT(*) As NumberOfRepairs
FROM repairs
GROUP BY RepairType
ORDER BY NumberOfRepairs ASC;

-- Q2: List all the unique vehicles (vehicle Id only) that have gone through some type of repairs.
SELECT DISTINCT VehicleID
FROM repairs;


-- 8. PartsRepaired
-- ======================================================

-- Q1: List parts by how often they are repaired
SELECT Part, COUNT(*) AS RepairCount
FROM partsRepaired
GROUP BY Part
ORDER BY RepairCount DESC;


-- 9. Cleaning
-- ======================================================

-- Q1: List all the vehicles that went through a premium level and interior cleaning that is sorted from most recent ot least.
SELECT *
FROM cleaning
WHERE CleaningArea = 'Interior' AND DetailLevel = 'Premium'
ORDER BY ServiceDate DESC;


-- 10. Rental
-- ======================================================

-- Q1: Count the number of rentals for each fuel level, label the count as Rental_Count and grouped by the fuel level
SELECT FuelLevel, COUNT(RentalID) AS Rental_Count
FROM Rental
GROUP BY FuelLevel;

-- Q2:Retrieve rentals that start after September 18, 2025, showing the rental ID, pickup date, and return date, and order the results by pickup date ascending.
SELECT RentalID, PickupDate, ReturnDate
FROM Rental
WHERE PickupDate > DATE '2025-09-18'
ORDER BY PickupDate ASC;


-- 11. Payment
-- ======================================================

-- Q1: Retrieve all distinct TotalAmount values from the Payment table that are less than or equal to a specified amount (e.g., $500)
-- Order the results by Total Amount in descending order
SELECT DISTINCT PaymentID, TotalAmount
FROM Payment
WHERE TotalAmount <= 500
ORDER BY TotalAmount DESC;

-- Q2: List all distinct payment methods used along with the total number of payments for each method
-- Label the count as Payment_Total, and order by the number of payments descending.
SELECT PaymentMethod, COUNT(PaymentID) AS Payment_Total
FROM Payment
GROUP BY PaymentMethod
ORDER BY Payment_Total DESC;


-- =======================================================================
-- Join Queries
-- ======================================================

-- Q1: Lists customer names, vehicle rented, and pickup/return dates
SELECT FirstName, LastName, VehicleID, PickupDate, ReturnDate
FROM Customer, Reservation, Rental
WHERE Customer.CustomerID = Reservation.CustomerID
AND Reservation.ReservationID = Rental.ReservationID
ORDER BY PickupDate

-- Q2: Show customer ID, with their reservation ID, vehicle models, rental cost, and payment method
SELECT c.CustomerID, res.ReservationID , v.Model, rent.RentalCost, p.PaymentMethod
FROM Customer c, Reservation res, Vehicle v, Rental rent, Payment p
WHERE c.CustomerID = res.CustomerID
AND res.VehicleID = v.VehicleID
AND res.ReservationID = rent.ReservationID
AND rent.RentalID = p.RentalID;

-- Q3: Count in Ascending order which models of vehicles have the most issues with brakes (so repair for brakes category)
SELECT Model, COUNT(*) AS EngineIssues
FROM vehicle, repairs
WHERE vehicle.VehicleID = repairs.VehicleID
AND  RepairType = 'Engine'
GROUP By Model;

-- Q4: List all the vehicles with the parts that have replaced
SELECT vehicle.VehicleID, Model, Plate, Part, RepairType
FROM vehicle, partsRepaired
WHERE vehicle.VehicleID = partsRepaired.VehicleID;

-- Q5: List all the vehicles with a mainteance record that had both some type of repair and some type of cleaning on same date
SELECT DISTINCT vehicle.VehicleID, CleaningArea, RepairType, repairs.ServiceDate
FROM vehicle, repairs, cleaning
WHERE vehicle.VehicleID = repairs.VehicleID
AND vehicle.VehicleID = cleaning.VehicleID
AND repairs.ServiceDate = cleaning.ServiceDate;


-- =======================================================================
-- Advanced Queries
-- ======================================================

-- Q1: Lists high spending customers
SELECT c.CustomerID, AVG(p.TotalAmount) AS AverageSpending
FROM Customer c, Reservation r, Rental t, Payment p
WHERE c.CustomerID = r.CustomerID
AND r.ReservationID = t.ReservationID
AND t.RentalID = p.RentalID
GROUP BY c.CustomerID
HAVING AVG(p.TotalAmount) > 700
ORDER BY AVG(p.TotalAmount) DESC;

-- Q2: Lists vehicles never rented
SELECT *
FROM Vehicle v
WHERE NOT EXISTS
(
    SELECT *
    FROM Reservation r, Rental t
    WHERE r.ReservationID = t.ReservationID
    AND r.VehicleID = v.VehicleID
);

-- Q3: Lists total revenue and average rental cost per vehicle type
SELECT v.VType, SUM(p.TotalAmount) AS TotalRevenue, AVG(p.TotalAmount) AS AverageRentalCost
FROM Vehicle v, Reservation r, Rental t, Payment p
WHERE v.VehicleID = r.VehicleID
AND r.ReservationID = t.ReservationID
AND t.RentalID = p.RentalID
GROUP BY v.VType
HAVING SUM(p.TotalAmount) > 0
ORDER BY TotalRevenue DESC;

-- Q4: Find customers with reservations but no payments
SELECT c.FirstName, c.CustomerID, r.ReservationID, rental.RentalID
FROM customer c, reservation r, rental
WHERE c.CustomerID = r.CustomerID AND
r.ReservationID = rental.ReservationID
MINUS
SELECT c.FirstName, c.CustomerID, r.ReservationID, rental.RentalID FROM customer c,
reservation r, rental, payment p
WHERE c.CustomerID = r.CustomerID AND
r.ReservationID = rental.ReservationID AND
rental.RentalID = p.RentalID;

-- Q5: Union of the vehicles with a rating greater than 4 and rating less than 2
SELECT Rating, ReviewID, Feedback
FROM review
WHERE Rating >= 4
UNION
SELECT Rating, ReviewID, Feedback
FROM review
WHERE Rating <= 2;

-- Q6: List of vehicles sent to maintenance more than 1 time
SELECT v.vehicleID, v.Model, COUNT(*) AS MaintenanceVisits
FROM vehicle v, maintenance
WHERE v.vehicleID = maintenance.vehicleID
GROUP BY v.vehicleID, v.Model
HAVING COUNT(*) > 1;

exit;
EOF
