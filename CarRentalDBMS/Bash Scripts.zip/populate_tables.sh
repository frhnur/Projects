#!/bin/bash
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib

read -p "Enter username: " user
read -sp "Enter password: " pwd
echo

sqlplus64 "${user}/${pwd}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- 1. Customer
-- ======================================================

-- All Customer Values Given
INSERT INTO Customer VALUES 
(1, 'Alice', 'K', 'Johnson', '416-111-2222', 'alice.j@gmail.com', '12', 'Maple St', 'Toronto', 'DL1001');
INSERT INTO Customer VALUES 
(2, 'Alice', 'K', 'Johnson', '416-444-2482', 'alice.j2@gmail.com', '13', 'Maple St', 'Toronto', 'DL1801');
INSERT INTO Customer VALUES 
(3, 'Bob', 'A', 'Smith', '416-333-4444', 'bob.smith@hotmail.com', '45', 'Oak Ave', 'Toronto', 'DL1002');
INSERT INTO Customer VALUES 
(4, 'Diana', 'M', 'Brown', '647-555-1212', 'diana.brown@yahoo.com', '23', 'Cedar Blvd', 'Mississauga', 'DL1004');
INSERT INTO Customer VALUES 
(5, 'Ethan', NULL, 'Wong', '905-222-3333', NULL, '56', 'Birch St', 'Toronto', 'DL1005');
-- No Customer MiddlenName/PhoneNumber
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, StreetNumber, StreetName, City, DriversLicense) VALUES 
(6, 'Apiena', 'Selvarajah', 'apiena.selvarajah@torontomu.ca', '89', 'Pine Rd', 'Ottawa', 'DL1003');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, StreetNumber, StreetName, City, DriversLicense) VALUES 
(7, 'Farah', 'Noor', 'farah2.noor@etorontomu.ca', '77', 'Spruce Ln', 'Brampton', 'DL1006');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, StreetNumber, StreetName, City, DriversLicense) VALUES 
(8, 'Aishwin', 'Jeevothayan', 'aishwin.jeevothayan@torontomu.ca', '34', 'Elm St', 'Toronto', 'DL1007');
-- No Customer MiddleName/Email
INSERT INTO Customer (CustomerID, FirstName, LastName, PhoneNumber, StreetNumber, StreetName, City, DriversLicense) VALUES 
(9, 'Hannah', 'Kim', '6471237890', '90', 'Ash Ave', 'Scarborough', 'DL1008');
INSERT INTO Customer (CustomerID, FirstName, LastName, PhoneNumber, StreetNumber, StreetName, City, DriversLicense) VALUES 
(10, 'Ivan', 'Patel', '9055674321', '11', 'Willow Dr', 'Mississauga', 'DL1009');
INSERT INTO Customer (CustomerID, FirstName, LastName, PhoneNumber, StreetNumber, StreetName, City, DriversLicense) VALUES 
(11, 'Julia', 'Garcia', '4167654321', '66', 'Poplar Ct', 'Toronto', 'DL1010');
INSERT INTO Customer (CustomerID, FirstName, LastName, PhoneNumber, StreetNumber, StreetName, City, DriversLicense) VALUES
(12, 'Simon', 'Patel', '9055474329', '11', 'Willow Dr', 'Mississauga', 'DL1011');


-- 3. Vehicle
-- =====================================================

-- All Vehicle Values Given
INSERT INTO Vehicle VALUES (101, 40, 49.99, 'Economy', 'ECO123', 'Toyota Corolla', 'Rented');
INSERT INTO Vehicle VALUES (102, 55, 120.00, 'Luxury', 'LUX456', 'BMW 5 Series', 'Rented');
INSERT INTO Vehicle VALUES (103, 50, 80.00, 'Economy', 'ECO789', 'Honda Civic', 'Maintenance');
INSERT INTO Vehicle VALUES (104, 65, 150.00, 'Luxury', 'LUX789', 'Mercedes E-Class', 'Available');
INSERT INTO Vehicle VALUES (105, 45, 60.00, 'Economy', 'ECO456', 'Hyundai Elantra', 'Rented');
INSERT INTO Vehicle VALUES (106, 70, 200.00, 'Luxury', 'LUX321', 'Audi A7', 'Rented');
INSERT INTO Vehicle VALUES (107, 48, 70.00, 'Economy', 'ECO654', 'Nissan Sentra', 'Rented');
INSERT INTO Vehicle VALUES (108, 55, 90.00, 'Economy', 'ECO852', 'Mazda 3', 'Available');
INSERT INTO Vehicle VALUES (109, 80, 250.00, 'Luxury', 'LUX159', 'Porsche Cayenne', 'Rented');
INSERT INTO Vehicle VALUES (110, 60, 110.00, 'Economy', 'ECO333', 'Kia Sportage', 'Rented');
INSERT INTO Vehicle VALUES (114, 55, 120.00, 'Luxury', 'LUX753', 'Mercedes C-Class', 'Maintenance');
INSERT INTO Vehicle VALUES (122, 55, 120.00, 'Luxury', 'MER101', 'Mercedes C-Class', 'Maintenance');
INSERT INTO Vehicle VALUES (123, 55, 120.00, 'Luxury', 'MER102', 'Mercedes C-Class', 'Maintenance');
INSERT INTO Vehicle VALUES (124, 55, 120.00, 'Economy', 'HON100', 'Honda Accord', 'Maintenance');
-- No Vehicle VStatus
INSERT INTO Vehicle (VehicleID, FuelCapacity, DailyRate, VType, Plate, Model) VALUES (111, 50, 95.00, 'Economy', 'ECO951', 'Honda Accord');
INSERT INTO Vehicle (VehicleID, FuelCapacity, DailyRate, VType, Plate, Model) VALUES (112, 65, 180.00, 'Luxury', 'LUX852', 'Lexus RX');
INSERT INTO Vehicle (VehicleID, FuelCapacity, DailyRate, VType, Plate, Model) VALUES (113, 45, 60.00, 'Economy', 'ECO753', 'Toyota Yaris');
INSERT INTO Vehicle (VehicleID, FuelCapacity, DailyRate, VType, Plate, Model) VALUES (115, 48, 70.00, 'Economy', 'ECO822', 'Nissan Versa');
INSERT INTO Vehicle (VehicleID, FuelCapacity, DailyRate, VType, Plate, Model) VALUES (116, 80, 250.00, 'Luxury', 'LUX951', 'Porsche 911');

-- 3. VehicleColour: Multivalued Attribute of Vehicle
-- =====================================================

-- All VehicleColour Values Given
INSERT INTO VehicleColour VALUES (101, 'Red');
INSERT INTO VehicleColour VALUES (101, 'Black');
INSERT INTO VehicleColour VALUES (102, 'White');
INSERT INTO VehicleColour VALUES (103, 'Blue');
INSERT INTO VehicleColour VALUES (104, 'Silver');
INSERT INTO VehicleColour VALUES (105, 'Grey');
INSERT INTO VehicleColour VALUES (106, 'Black');
INSERT INTO VehicleColour VALUES (107, 'Green');
INSERT INTO VehicleColour VALUES (108, 'Blue');
INSERT INTO VehicleColour VALUES (109, 'White');
INSERT INTO VehicleColour VALUES (110, 'Orange');
INSERT INTO VehicleColour VALUES (111, 'Red');
INSERT INTO VehicleColour VALUES (111, 'Black');
INSERT INTO VehicleColour VALUES (112, 'White');
INSERT INTO VehicleColour VALUES (112, 'Silver');
INSERT INTO VehicleColour VALUES (114, 'Black');
INSERT INTO VehicleColour VALUES (114, 'Blue');
INSERT INTO VehicleColour VALUES (116, 'Yellow');
INSERT INTO VehicleColour VALUES (116, 'Black');
INSERT INTO VehicleColour VALUES (113, 'Blue');
INSERT INTO VehicleColour VALUES (115, 'Grey');


-- 4. Review
-- =====================================================

-- All Review Values Given
INSERT INTO Review VALUES (205, 3, TO_DATE('2025-09-16','YYYY-MM-DD'), 'Decent car, but could be cleaner.', 'Online', 5, 105);
-- No Review ReviewDate
INSERT INTO Review (ReviewID, Rating, Feedback, WritingMethod, CustomerID, VehicleID) VALUES (206, 5, 'Amazing luxury ride, very smooth.', 'Text', 6, 106);
-- No Review ReviewDate/Feedback/WritingMethod
INSERT INTO Review (ReviewID, Rating, CustomerID, VehicleID) VALUES (207, 4, 7, 107);
INSERT INTO Review (ReviewID, Rating, CustomerID, VehicleID) VALUES (208, 1, 8, 108);
-- No Review ReviewDate/WritingMethod
INSERT INTO Review (ReviewID, Rating, Feedback, CustomerID, VehicleID) VALUES (209, 2,
'Poor job of interior cleaning, ', 9, 109);
INSERT INTO Review (ReviewID, Rating, Feedback, CustomerID, VehicleID) VALUES (211, 1,
'Terrible Service', 11, 111);
-- No Review ReviewDate/Feedback/WritingMethod
INSERT INTO Review (ReviewID, Rating, CustomerID, VehicleID) VALUES (210, 4, 10, 110);


-- 5. Reservation
-- ====================================================

-- All Reservation Values Given
INSERT INTO Reservation VALUES (301, 'Confirmed', TO_DATE('2025-09-15','YYYY-MM-DD'), TO_DATE('2025-09-20','YYYY-MM-DD'), 1, 101);
INSERT INTO Reservation VALUES (302, 'Confirmed', TO_DATE('2025-09-18','YYYY-MM-DD'), TO_DATE('2025-09-22','YYYY-MM-DD'), 2, 102);
INSERT INTO Reservation VALUES (303, 'Pending', TO_DATE('2025-09-25','YYYY-MM-DD'), TO_DATE('2025-09-28','YYYY-MM-DD'), 3, 103);
INSERT INTO Reservation VALUES (304, 'Cancelled', TO_DATE('2025-09-05','YYYY-MM-DD'), TO_DATE('2025-09-10','YYYY-MM-DD'), 4, 104);
INSERT INTO Reservation VALUES (305, 'Confirmed', TO_DATE('2025-09-12','YYYY-MM-DD'), TO_DATE('2025-09-15','YYYY-MM-DD'), 5, 105);
INSERT INTO Reservation VALUES (306, 'Confirmed', TO_DATE('2025-09-20','YYYY-MM-DD'), TO_DATE('2025-09-24','YYYY-MM-DD'), 6, 106);
INSERT INTO Reservation VALUES (307, 'Confirmed', TO_DATE('2025-09-07','YYYY-MM-DD'), TO_DATE('2025-09-11','YYYY-MM-DD'), 7, 107);
INSERT INTO Reservation VALUES (308, 'Pending', TO_DATE('2025-09-29','YYYY-MM-DD'), TO_DATE('2025-10-02','YYYY-MM-DD'), 8, 108);
INSERT INTO Reservation VALUES (309, 'Confirmed', TO_DATE('2025-09-01','YYYY-MM-DD'), TO_DATE('2025-09-05','YYYY-MM-DD'), 9, 109);
INSERT INTO Reservation VALUES (310, 'Confirmed', TO_DATE('2025-09-22','YYYY-MM-DD'), TO_DATE('2025-09-27','YYYY-MM-DD'), 10, 110);
INSERT INTO Reservation VALUES (311, 'Confirmed', TO_DATE('2025-10-05','YYYY-MM-DD'), TO_DATE('2025-10-07','YYYY-MM-DD'), 11, 115);
INSERT INTO Reservation VALUES (312, 'Confirmed', TO_DATE('2025-10-16','YYYY-MM-DD'), TO_DATE('2025-10-27','YYYY-MM-DD'), 12, 116);


-- 6. Maintenance: Weak Entity
-- ====================================================

-- All Maintenance Values Given
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-05','YYYY-MM-DD'), 'Needs_Maintenance', 103);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-18','YYYY-MM-DD'), 'Maintenance_Completed', 111);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-20','YYYY-MM-DD'), 'Maintenance_Completed', 112);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-22','YYYY-MM-DD'), 'Under_Maintenance', 114);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-23','YYYY-MM-DD'), 'Under_Maintenance', 122);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-25','YYYY-MM-DD'), 'Under_Maintenance', 123);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-25','YYYY-MM-DD'), 'Under_Maintenance', 124);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-26','YYYY-MM-DD'), 'Under_Maintenance', 122);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-27','YYYY-MM-DD'), 'Under_Maintenance', 123);
INSERT INTO Maintenance VALUES (TO_DATE('2025-09-28','YYYY-MM-DD'), 'Under_Maintenance', 124);
INSERT INTO Maintenance VALUES (TO_DATE('2025-10-12','YYYY-MM-DD'), 'Needs_Maintenance', 112);
INSERT INTO Maintenance VALUES (TO_DATE('2025-10-15','YYYY-MM-DD'), 'Under_Maintenance', 124);


-- 7. Repairs: Subclass of Maintenance
-- ===================================================

-- All Repairs Values Given
INSERT INTO Repairs VALUES ('Engine', 103, TO_DATE('2025-09-05','YYYY-MM-DD'));
INSERT INTO Repairs VALUES ('Brake', 111, TO_DATE('2025-09-18','YYYY-MM-DD'));
INSERT INTO Repairs VALUES ('Engine', 114, TO_DATE('2025-09-22','YYYY-MM-DD'));
INSERT INTO Repairs VALUES ('Engine', 122, TO_DATE('2025-09-23','YYYY-MM-DD'));
INSERT INTO Repairs VALUES ('Engine', 123, TO_DATE('2025-09-25','YYYY-MM-DD'));
INSERT INTO Repairs VALUES ('Brake', 124, TO_DATE('2025-09-25','YYYY-MM-DD'));


-- 8. PartsRepaired: Multivalued Attribute of Repair
-- ==================================================

-- All PartsRepaired Values Given
INSERT INTO PartsRepaired VALUES (103, TO_DATE('2025-09-05','YYYY-MM-DD'), 'Alternator', 'Engine');
INSERT INTO PartsRepaired VALUES (103, TO_DATE('2025-09-05','YYYY-MM-DD'), 'Battery', 'Engine');
INSERT INTO PartsRepaired VALUES (111, TO_DATE('2025-09-18','YYYY-MM-DD'), 'Brake Pads', 'Brake');
INSERT INTO PartsRepaired VALUES (111, TO_DATE('2025-09-18','YYYY-MM-DD'), 'Brake Disc', 'Brake');
INSERT INTO PartsRepaired VALUES (114, TO_DATE('2025-09-22','YYYY-MM-DD'), 'Spark Plugs', 'Engine');
INSERT INTO PartsRepaired VALUES (122, TO_DATE('2025-09-23','YYYY-MM-DD'), 'Spark Plugs', 'Engine');
INSERT INTO PartsRepaired VALUES (123, TO_DATE('2025-09-25','YYYY-MM-DD'), 'Spark Plugs', 'Engine');
INSERT INTO PartsRepaired VALUES (124, TO_DATE('2025-09-25','YYYY-MM-DD'), 'Brake Pads', 'Brake');


-- 9. Cleaning: Subclass of Maintenance
-- ===================================================

-- All Cleaning Values Given
INSERT INTO Cleaning VALUES ('Interior', 'Deep', 103, TO_DATE('2025-09-05','YYYY-MM-DD'));
INSERT INTO Cleaning VALUES ('Exterior', 'Premium', 103, TO_DATE('2025-09-05','YYYY-MM-DD'));
INSERT INTO Cleaning VALUES ('Interior', 'Premium', 112, TO_DATE('2025-09-20','YYYY-MM-DD'));
INSERT INTO Cleaning VALUES ('Exterior', 'Deep', 112, TO_DATE('2025-09-20','YYYY-MM-DD'));
INSERT INTO Cleaning VALUES ('Interior', 'Basic', 114, TO_DATE('2025-09-22','YYYY-MM-DD'));
INSERT INTO Cleaning VALUES ('Interior', 'Basic', 124, TO_DATE('2025-09-25','YYYY-MM-DD'));


-- 10. Rental
-- ==================================================

-- All Rental Vaues Given
INSERT INTO Rental VALUES (401, TO_DATE('2025-09-15','YYYY-MM-DD'), TO_DATE('2025-09-20','YYYY-MM-DD'), 250.00, 40.00, 90, 301);
INSERT INTO Rental VALUES (402, TO_DATE('2025-09-18','YYYY-MM-DD'), TO_DATE('2025-09-22','YYYY-MM-DD'), 480.00, 60.00, 80, 302);
INSERT INTO Rental VALUES (403, TO_DATE('2025-09-12','YYYY-MM-DD'), TO_DATE('2025-09-15','YYYY-MM-DD'), 180.00, 30.00, 85, 305);
INSERT INTO Rental VALUES (404, TO_DATE('2025-09-20','YYYY-MM-DD'), TO_DATE('2025-09-24','YYYY-MM-DD'), 800.00, 70.00, 75, 306);
INSERT INTO Rental VALUES (405, TO_DATE('2025-09-07','YYYY-MM-DD'), TO_DATE('2025-09-11','YYYY-MM-DD'), 280.00, 35.00, 88, 307);
INSERT INTO Rental VALUES (406, TO_DATE('2025-09-01','YYYY-MM-DD'), TO_DATE('2025-09-05','YYYY-MM-DD'), 1000.00, 90.00, 70, 309);
INSERT INTO Rental VALUES (407, TO_DATE('2025-09-22','YYYY-MM-DD'), TO_DATE('2025-09-27','YYYY-MM-DD'), 500.00, 50.00, 82, 310);
INSERT INTO Rental VALUES (408, TO_DATE('2025-09-01','YYYY-MM-DD'), TO_DATE('2025-09-05','YYYY-MM-DD'), 1000.00, 90.00, 70, 311);
INSERT INTO Rental VALUES (409, TO_DATE('2025-09-22','YYYY-MM-DD'), TO_DATE('2025-09-27','YYYY-MM-DD'), 500.00, 50.00, 82, 312);


-- 11. Payment
-- ==================================================

-- All Payment Values Given
INSERT INTO Payment VALUES (501, TO_DATE('2025-09-20','YYYY-MM-DD'), 'Credit', 290.00, 401);
INSERT INTO Payment VALUES (502, TO_DATE('2025-09-22','YYYY-MM-DD'), 'Debit', 540.00, 402);
INSERT INTO Payment VALUES (505, TO_DATE('2025-09-15','YYYY-MM-DD'), 'Cash', 210.00, 403);
INSERT INTO Payment VALUES (506, TO_DATE('2025-09-24','YYYY-MM-DD'), 'Credit', 870.00, 404);
INSERT INTO Payment VALUES (507, TO_DATE('2025-09-11','YYYY-MM-DD'), 'Mobile', 315.00, 405);
INSERT INTO Payment VALUES (509, TO_DATE('2025-09-05','YYYY-MM-DD'), 'Online', 1090.00, 406);
INSERT INTO Payment VALUES (510, TO_DATE('2025-09-27','YYYY-MM-DD'), 'Credit', 550.00, 407);

exit;
EOF
