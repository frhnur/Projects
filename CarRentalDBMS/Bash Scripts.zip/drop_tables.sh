#!/bin/bash
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib

read -p "Enter username: " user
read -sp "Enter password: " pwd
echo

sqlplus64 "${user}/${pwd}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- Drop Views
-- ======================================================
DROP VIEW customer_reservations CASCADE CONSTRAINTS;
DROP VIEW customers_with_phone CASCADE CONSTRAINTS;
DROP VIEW customer_info CASCADE CONSTRAINTS;
DROP VIEW luxury_vehicles CASCADE CONSTRAINTS;
DROP VIEW vehiclerepairs_andparts CASCADE CONSTRAINTS;
DROP VIEW pending_reservations CASCADE CONSTRAINTS;


-- Drop Tables
-- ======================================================
DROP TABLE Customer CASCADE CONSTRAINTS;
DROP TABLE Vehicle CASCADE CONSTRAINTS;
DROP TABLE VehicleColour CASCADE CONSTRAINTS;
DROP TABLE Review CASCADE CONSTRAINTS;
DROP TABLE Reservation CASCADE CONSTRAINTS;
DROP TABLE Maintenance CASCADE CONSTRAINTS;
DROP TABLE Repairs CASCADE CONSTRAINTS;
DROP TABLE PartsRepaired CASCADE CONSTRAINTS;
DROP TABLE Cleaning CASCADE CONSTRAINTS;
DROP TABLE Rental CASCADE CONSTRAINTS;
DROP TABLE Payment CASCADE CONSTRAINTS;

exit;
EOF
