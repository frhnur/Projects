#!/bin/bash
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib

read -p "Enter username: " user
read -sp "Enter password: " pwd
echo

sqlplus64 "${user}/${pwd}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

-- 1. customer_reservations: Shows each customer names, vehicle they reserved and dates - uses join
-- ==================================================================================================

Create VIEW customer_reservations(FirstName, LastName, VehicleID, PickupDate, ReturnDate) AS (
    SELECT FirstName, LastName, VehicleID, PPickupDate, PReturnDate
    FROM Customer, Reservation
     WHERE Customer.CustomerID = Reservation.CustomerID
);

-- 2. customers_with_phone: Lists all customers who have provided a phone number
-- ===================================================================================================

CREATE VIEW customers_with_phone AS (
    SELECT *
    FROM Customer
    WHERE PhoneNumber IS NOT NULL
);

-- 3. customer_info: Shows customers alongside their rental cost, payment method, and total amount paid - uses join
-- ====================================================================================================

CREATE VIEW customer_info(CustomerID, RentalCost, PaymentMethod, TotalAmount) AS (
    SELECT c.CustomerID, rent.RentalCost, p.PaymentMethod, p.TotalAmount
    FROM Customer c, Reservation res, Rental rent, Payment p
    WHERE c.CustomerID = res.CustomerID
    AND res.ReservationID = rent.ReservationID
    AND rent.RentalID = p.RentalID
);

-- 4. luxury_vehicles: Lists all vehicles type luxury with their ID, model, and daily rate
-- =====================================================================================================

CREATE VIEW luxury_vehicles(VehicleID, Model, DailyRate) AS (
    SELECT VehicleID, Model, DailyRate
    FROM Vehicle
    WHERE VType = 'Luxury'
);

-- 5. vehiclerepairs_andparts: Show Vehicles with associated repair type, parts repaired and service date
-- =====================================================================================================

CREATE VIEW vehiclerepairs_andparts AS (
    SELECT vehicle.VehicleID, Model, repairs.RepairType, repairs.ServiceDate, Part
    FROM vehicle, repairs, partsRepaired
    WHERE vehicle.VehicleID = repairs.VehicleID
    AND partsRepaired.VehicleID = repairs.VehicleID
    AND partsRepaired.ServiceDate = repairs.ServiceDate
);

-- 6. pending_reservations: Shows all reservations that are still pending by customer, vehicle, and date details
-- ======================================================================================================

CREATE VIEW pending_reservations AS (
    SELECT vehicle.VehicleID, Model, customer.CustomerID, FirstName, LastName, Email, reservation.ReservationID, RStatus, PPickupDate, PReturnDate
    FROM vehicle, customer, reservation
    WHERE vehicle.VehicleID = reservation.VehicleID
    AND customer.CustomerID = reservation.CustomerID -- NEED to relate the customers back to the reservations
    AND RStatus = 'Pending'
);

exit;
EOF
